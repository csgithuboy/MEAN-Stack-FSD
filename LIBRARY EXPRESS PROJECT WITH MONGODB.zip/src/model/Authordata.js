const mongoose= require('mongoose');//accessing mongoos package
mongoose.connect('mongodb://localhost:27017/libraryDb',
{
useNewUrlParser: true,
useCreateIndex: true,
useUnifiedTopology:true,
useFindAndModify:false
});// connection string
//console.log(mongoose.connection.readyState)
const Schema=mongoose.Schema;//schema definition
const AuthorSchema = new Schema({
titl: String,
author: String,
place: String,
image: String
//imag will be saved pith fil
},{strict:false});
//model creation
var Authordata=mongoose.model('authordata',AuthorSchema);
module.exports=Authordata;
