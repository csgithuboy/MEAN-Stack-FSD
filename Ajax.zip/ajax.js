function ajax() {
    var xhttp=new XMLHttpRequest();
    xhttp.onreadystatechange=function(){
        if (this.readyState==4&&this.status==200) {
            var response=JSON.parse(this.responseText);
            var Jlist=response.list;
            var output="";

            for (var i = 0; i < Jlist.length; i++) {
                output+="<tr>";
                output+="<th scope=row>"+(i+1)+"</th>";
                output+="<td>"+Jlist[i].item+"</td>";
                output+="<td>"+Jlist[i].quantity+"</td>";
                output+="<td>"+Jlist[i].unit+"</td>";
                output+="<td>"+Jlist[i].category+"</td>";
                output+="</tr>";
            }
            document.getElementById("demo").innerHTML=output;
        }
    }
    xhttp.open("GET","list.json",true);   
    xhttp.send();
}