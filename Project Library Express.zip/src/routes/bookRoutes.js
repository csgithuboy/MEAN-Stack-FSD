const express=require('express')
const booksRouter=express.Router();
function router(nav){
var books=[
    {
        title:'goyfouyf',
        author:'uykfykf',
        genre:'drama',
        img:"a.jpeg"
    },
    {
        title:'goyfouyf',
        author:'uykfykf',
        genre:'drama',
        img:"a2.jpeg"
    },
    {
        title:'goyfouyf',
        author:'uykfykf',
        genre:'drama',
        img:"a3.jpeg"
    }
]

booksRouter.get('/',function(req,res){
    res.render("books",
    {
        nav,
        title:"Books",
        books
    })
})

booksRouter.get('/:id', function(req,res) {
    const id=req.params.id;
    res.render("book",
    {
    nav,
    title: "Book",
    book:books[id]
    })
    })
return booksRouter;    
}
module.exports=router;    